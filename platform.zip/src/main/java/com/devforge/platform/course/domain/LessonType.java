package com.devforge.platform.course.domain;

public enum LessonType {
    LECTURE,   // text + video
    PRACTICE,  // code exercise
    QUIZ       // Test
}